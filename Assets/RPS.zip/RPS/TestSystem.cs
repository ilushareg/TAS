﻿using Entitas;
using UnityEngine;
using System.Collections.Generic;

public class TestSystem : ReactiveSystem<GameEntity>
{
	readonly GameContext _context;

	public TestSystem(Contexts contexts) : base(contexts.game)
	{
		_context = contexts.game;
	}

	public void Execute()
	{
		//Debug.Log ("asd");
//		if (Input.GetMouseButtonDown(0))
//		{
//			_context.CreateEntity().AddDebugMessage("Left Mouse Button Clicked");
//		}
//
//		if (Input.GetMouseButtonDown(1))
//		{
//			_context.CreateEntity().AddDebugMessage("Right Mouse Button Clicked");
//		}
	}



	protected override Collector<GameEntity> GetTrigger(IContext<GameEntity> context)
	{
		return null;
//		return context.CreateCollector(GameMatcher.Test);
	}

	protected override bool Filter(GameEntity entity)
	{
		return entity.hasDebugMessage;
	}

	protected override void Execute(List<GameEntity> entities)
	{
		foreach (var e in entities)
		{
			Debug.Log(e.debugMessage.message);
		}
	}
}
