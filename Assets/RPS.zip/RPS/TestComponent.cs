﻿using Entitas;

[Game]
public class TestComponent : IComponent
{
	public string message;
}


